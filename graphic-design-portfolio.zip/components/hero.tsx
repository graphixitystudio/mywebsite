"use client"

import { ArrowDown, Github, Linkedin, Instagram, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center px-6 lg:px-12 pt-20 overflow-hidden">
      <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent"></div>

      <div className="max-w-7xl mx-auto w-full grid lg:grid-cols-2 gap-12 items-center relative z-10">
        <div className="space-y-6 lg:pr-8">
          <div className="space-y-4">
            <p className="text-lg text-muted-foreground font-medium">Hello, It's Me</p>

            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight leading-none">Dax</h1>

            <div className="text-2xl md:text-3xl lg:text-4xl font-medium">
              <span className="text-muted-foreground">And I'm a </span>
              <span className="text-primary">Graphic Designer</span>
            </div>

            <p className="text-base text-muted-foreground max-w-xl leading-relaxed pt-2">
              Transforming ideas into stunning visual experiences through professional design and cinematic video
              editing. Let's create something extraordinary together.
            </p>
          </div>

          <div className="flex items-center gap-4 pt-4">
            <a
              href="#"
              className="w-11 h-11 rounded-full border-2 border-primary flex items-center justify-center hover:bg-primary hover:shadow-lg hover:shadow-primary/50 transition-all duration-300"
            >
              <Github className="h-5 w-5" />
            </a>
            <a
              href="#"
              className="w-11 h-11 rounded-full border-2 border-primary flex items-center justify-center hover:bg-primary hover:shadow-lg hover:shadow-primary/50 transition-all duration-300"
            >
              <Linkedin className="h-5 w-5" />
            </a>
            <a
              href="#"
              className="w-11 h-11 rounded-full border-2 border-primary flex items-center justify-center hover:bg-primary hover:shadow-lg hover:shadow-primary/50 transition-all duration-300"
            >
              <Instagram className="h-5 w-5" />
            </a>
            <a
              href="#"
              className="w-11 h-11 rounded-full border-2 border-primary flex items-center justify-center hover:bg-primary hover:shadow-lg hover:shadow-primary/50 transition-all duration-300"
            >
              <Mail className="h-5 w-5" />
            </a>
          </div>

          <div className="pt-6">
            <Button
              size="lg"
              className="px-8 py-6 text-base font-semibold rounded-full bg-primary hover:bg-primary/90 shadow-lg shadow-primary/50 hover:shadow-xl hover:shadow-primary/60 transition-all duration-300"
            >
              Download CV
            </Button>
          </div>
        </div>

        <div className="flex items-center justify-center lg:justify-end">
          <div className="relative">
            <div className="relative w-[350px] h-[400px]">
              {/* Glow effect */}
              <div className="absolute inset-0 hexagon-glow"></div>

              {/* Main hexagonal container */}
              <div className="hexagon-container">
                <img
                  src="/images/api-attachments-rb48reljzukmnd5ijj6gq.jpg"
                  alt="Dax - Professional graphic designer and video editor"
                  className="hexagon-image"
                />
              </div>
            </div>

            {/* Decorative floating elements */}
            <div className="absolute -top-10 -left-10 w-20 h-20 bg-primary/20 rounded-full blur-2xl animate-float"></div>
            <div
              className="absolute -bottom-10 -right-10 w-24 h-24 bg-primary/20 rounded-full blur-2xl animate-float"
              style={{ animationDelay: "2s" }}
            ></div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <a
          href="#work"
          className="inline-flex flex-col items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
        >
          <ArrowDown className="h-5 w-5" />
        </a>
      </div>
    </section>
  )
}
