"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Play, ImageIcon } from "lucide-react"

const projects = [
  {
    title: "Premium Brand Identity",
    category: "Graphic Design",
    tags: ["Branding", "Logo"],
    image: "https://placehold.co/600x400?text=Luxury+brand+identity+design+with+elegant+gold+accents",
    description: "Complete brand identity for luxury fashion brand",
    type: "design",
  },
  {
    title: "Cinematic Product Video",
    category: "Video Editing",
    tags: ["Motion", "Color Grading"],
    image: "https://placehold.co/600x400?text=Cinematic+product+video+with+dramatic+lighting",
    description: "High-end product video with color grading",
    type: "video",
  },
  {
    title: "Modern Tech Branding",
    category: "Graphic Design",
    tags: ["Tech", "Minimalist"],
    image: "https://placehold.co/600x400?text=Modern+technology+branding+with+geometric+shapes",
    description: "Contemporary brand design for tech startup",
    type: "design",
  },
  {
    title: "Music Video Production",
    category: "Video Editing",
    tags: ["Creative", "Effects"],
    image: "https://placehold.co/600x400?text=Artistic+music+video+with+creative+transitions",
    description: "Creative music video with visual effects",
    type: "video",
  },
  {
    title: "Social Media Campaign",
    category: "Graphic Design",
    tags: ["Social", "Marketing"],
    image: "https://placehold.co/600x400?text=Bold+social+media+campaign+graphics",
    description: "Multi-platform social media campaign",
    type: "design",
  },
  {
    title: "Corporate Documentary",
    category: "Video Editing",
    tags: ["Documentary", "Pro"],
    image: "https://placehold.co/600x400?text=Professional+corporate+documentary",
    description: "Professional corporate storytelling",
    type: "video",
  },
]

export function Work() {
  return (
    <section id="work" className="py-24 px-6 lg:px-12 relative">
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="space-y-4 mb-16 text-center">
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
            My <span className="text-primary">Portfolio</span>
          </h2>
          <p className="text-base text-muted-foreground max-w-2xl mx-auto">
            Recent projects blending creativity and technical excellence
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <Card
              key={index}
              className="group overflow-hidden border-border hover:border-primary transition-all duration-300 cursor-pointer bg-card/50 backdrop-blur-sm hover:shadow-lg hover:shadow-primary/20"
            >
              <div className="aspect-[4/3] overflow-hidden bg-muted relative">
                <img
                  src={project.image || "/placeholder.svg"}
                  alt={project.description}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  {project.type === "video" ? (
                    <Play className="h-12 w-12 text-primary" />
                  ) : (
                    <ImageIcon className="h-12 w-12 text-primary" />
                  )}
                </div>
              </div>
              <div className="p-5 space-y-3">
                <Badge
                  variant="secondary"
                  className="text-xs font-semibold bg-primary/20 text-primary border-primary/30"
                >
                  {project.category}
                </Badge>
                <h3 className="text-lg font-bold group-hover:text-primary transition-colors duration-300">
                  {project.title}
                </h3>
                <p className="text-sm text-muted-foreground">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, tagIndex) => (
                    <span
                      key={tagIndex}
                      className="text-xs text-muted-foreground font-medium px-2 py-1 rounded bg-muted/50"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
