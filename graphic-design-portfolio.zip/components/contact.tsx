"use client"

import { Mail, Linkedin, Instagram, Github, Send, MapPin, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"

export function Contact() {
  return (
    <section id="contact" className="py-32 px-6 lg:px-12 bg-muted/30 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse"></div>
      <div
        className="absolute bottom-0 right-0 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse"
        style={{ animationDelay: "2s" }}
      ></div>

      <div className="max-w-6xl mx-auto relative z-10">
        <div className="text-center space-y-6 mb-20 animate-fade-up">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
            <span className="text-sm font-semibold text-primary uppercase tracking-wider">Get In Touch</span>
          </div>
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight bg-gradient-to-r from-foreground to-muted-foreground bg-clip-text text-transparent">
            Let's Create Together
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto text-pretty leading-relaxed">
            Have a project in mind? I'd love to hear about it. Let's collaborate and bring your creative vision to life.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          <Card className="p-10 space-y-8 border-border hover:border-primary transition-all duration-500 bg-card/50 backdrop-blur-sm shadow-xl animate-slide-in-left">
            <div className="space-y-2">
              <h3 className="text-2xl font-bold">Send a Message</h3>
              <p className="text-sm text-muted-foreground">
                Fill out the form and I'll get back to you within 24 hours
              </p>
            </div>

            <form className="space-y-6">
              <div className="space-y-3">
                <label htmlFor="name" className="text-sm font-semibold">
                  Full Name
                </label>
                <Input
                  id="name"
                  placeholder="John Doe"
                  className="h-12 bg-background/50 border-border focus:border-primary transition-all duration-300"
                />
              </div>

              <div className="space-y-3">
                <label htmlFor="email" className="text-sm font-semibold">
                  Email Address
                </label>
                <Input
                  id="email"
                  type="email"
                  placeholder="john@example.com"
                  className="h-12 bg-background/50 border-border focus:border-primary transition-all duration-300"
                />
              </div>

              <div className="space-y-3">
                <label htmlFor="subject" className="text-sm font-semibold">
                  Subject
                </label>
                <Input
                  id="subject"
                  placeholder="Project inquiry"
                  className="h-12 bg-background/50 border-border focus:border-primary transition-all duration-300"
                />
              </div>

              <div className="space-y-3">
                <label htmlFor="message" className="text-sm font-semibold">
                  Message
                </label>
                <Textarea
                  id="message"
                  placeholder="Tell me about your project, goals, and timeline..."
                  rows={6}
                  className="bg-background/50 border-border focus:border-primary transition-all duration-300 resize-none"
                />
              </div>

              <Button
                className="w-full h-12 text-base font-semibold hover:scale-105 transition-all duration-300 shadow-lg shadow-primary/30"
                size="lg"
              >
                <Send className="h-5 w-5 mr-2" />
                Send Message
              </Button>
            </form>
          </Card>

          <div className="space-y-8 animate-slide-in-right">
            <Card className="p-8 space-y-6 border-border bg-card/50 backdrop-blur-sm">
              <h3 className="text-2xl font-bold">Contact Information</h3>

              <div className="space-y-6">
                <a
                  href="mailto:dax@graphixity.com"
                  className="flex items-start gap-4 text-muted-foreground hover:text-primary transition-colors duration-300 group"
                >
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors duration-300">
                    <Mail className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <div className="font-semibold text-foreground mb-1">Email</div>
                    <div className="text-sm">dax@graphixity.com</div>
                  </div>
                </a>

                <div className="flex items-start gap-4 text-muted-foreground">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <MapPin className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <div className="font-semibold text-foreground mb-1">Location</div>
                    <div className="text-sm">Available Worldwide</div>
                  </div>
                </div>

                <div className="flex items-start gap-4 text-muted-foreground">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Clock className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <div className="font-semibold text-foreground mb-1">Response Time</div>
                    <div className="text-sm">Within 24 hours</div>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-8 space-y-6 border-border bg-card/50 backdrop-blur-sm">
              <h3 className="text-2xl font-bold">Follow Me</h3>
              <p className="text-sm text-muted-foreground">
                Connect with me on social media for updates and inspiration
              </p>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  size="icon"
                  asChild
                  className="h-12 w-12 border-2 hover:bg-primary hover:border-primary hover:scale-110 transition-all duration-300 bg-transparent"
                >
                  <a href="#" aria-label="LinkedIn" target="_blank" rel="noopener noreferrer">
                    <Linkedin className="h-5 w-5" />
                  </a>
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  asChild
                  className="h-12 w-12 border-2 hover:bg-primary hover:border-primary hover:scale-110 transition-all duration-300 bg-transparent"
                >
                  <a href="#" aria-label="Instagram" target="_blank" rel="noopener noreferrer">
                    <Instagram className="h-5 w-5" />
                  </a>
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  asChild
                  className="h-12 w-12 border-2 hover:bg-primary hover:border-primary hover:scale-110 transition-all duration-300 bg-transparent"
                >
                  <a href="#" aria-label="GitHub" target="_blank" rel="noopener noreferrer">
                    <Github className="h-5 w-5" />
                  </a>
                </Button>
              </div>
            </Card>

            <div className="p-8 rounded-2xl bg-gradient-to-br from-primary/20 via-primary/10 to-transparent border border-primary/30 backdrop-blur-sm">
              <p className="text-sm leading-relaxed text-foreground/90">
                <span className="font-semibold text-primary">Available for freelance projects</span> and long-term
                collaborations. Let's work together to create something extraordinary that exceeds your expectations.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-24 pt-12 border-t border-border text-center space-y-4">
          <div className="flex items-center justify-center gap-2">
            <img src="/images/api-attachments-croluworz6ovpi68gg2cb.png" alt="Graphixity logo" className="h-8 w-auto" />
          </div>
          <p className="text-sm text-muted-foreground">© 2025 Dax - Graphixity Studio. All rights reserved.</p>
        </div>
      </div>
    </section>
  )
}
