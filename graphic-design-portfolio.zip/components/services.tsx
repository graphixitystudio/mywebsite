"use client"

import { Palette, Film, Layers, Wand2, Sparkles, Zap } from "lucide-react"
import { Card } from "@/components/ui/card"

const services = [
  {
    icon: Palette,
    title: "Graphic Design",
    description: "Brand identities, logos, and visual designs that make lasting impressions.",
  },
  {
    icon: Film,
    title: "Video Editing",
    description: "Professional video production, color grading, and cinematic storytelling.",
  },
  {
    icon: Layers,
    title: "Motion Graphics",
    description: "Dynamic animations and visual effects that bring content to life.",
  },
  {
    icon: Wand2,
    title: "Creative Direction",
    description: "Strategic visual planning for cohesive and impactful campaigns.",
  },
  {
    icon: Sparkles,
    title: "Social Media Content",
    description: "Engaging visual content optimized for social platforms.",
  },
  {
    icon: Zap,
    title: "Post-Production",
    description: "Professional editing, color correction, and finishing touches.",
  },
]

export function Services() {
  return (
    <section id="services" className="py-24 px-6 lg:px-12 relative overflow-hidden">
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="space-y-4 mb-16 text-center">
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
            My <span className="text-primary">Skills</span>
          </h2>
          <p className="text-base text-muted-foreground max-w-2xl mx-auto">
            Comprehensive creative solutions to elevate your brand
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <Card
              key={index}
              className="p-6 space-y-4 border-border hover:border-primary transition-all duration-300 group bg-card/50 backdrop-blur-sm hover:shadow-lg hover:shadow-primary/20"
            >
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors duration-300">
                <service.icon className="h-7 w-7 text-primary" />
              </div>

              <div className="space-y-2">
                <h3 className="text-xl font-bold group-hover:text-primary transition-colors duration-300">
                  {service.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{service.description}</p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
