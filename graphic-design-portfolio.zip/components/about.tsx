"use client"

export function About() {
  const skills = [
    { name: "Adobe Photoshop", level: 95 },
    { name: "Adobe Illustrator", level: 90 },
    { name: "Adobe Premiere Pro", level: 92 },
    { name: "After Effects", level: 88 },
    { name: "DaVinci Resolve", level: 85 },
    { name: "Figma", level: 87 },
  ]

  return (
    <section id="about" className="py-24 px-6 lg:px-12 bg-muted/30 relative overflow-hidden">
      <div className="max-w-6xl mx-auto relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-start">
          {/* Left - Image */}
          <div className="space-y-6">
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
              About <span className="text-primary">Me</span>
            </h2>
            <div className="relative group">
              <div className="w-full max-w-sm overflow-hidden rounded-2xl bg-muted border-2 border-primary/20 shadow-xl">
                <img
                  src="/images/api-attachments-rb48reljzukmnd5ijj6gq.jpg"
                  alt="Dax - Professional graphic designer and video editor"
                  className="w-full h-auto object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
            </div>
          </div>

          {/* Right - Content */}
          <div className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-2xl md:text-3xl font-bold">
                Graphic Designer & <span className="text-primary">Video Editor</span>
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                I'm Dax, a passionate visual creator with over 8 years of experience in graphic design and video
                editing. I specialize in transforming ideas into captivating visual stories that resonate with audiences
                and drive results.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                From brand identities to cinematic videos, I bring creativity, technical expertise, and strategic
                thinking to every project. My work is driven by attention to detail and a commitment to excellence.
              </p>
            </div>

            <div className="space-y-4 pt-4">
              <h4 className="text-lg font-semibold">Professional Skills</h4>
              <div className="space-y-3">
                {skills.map((skill, index) => (
                  <div key={index} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium">{skill.name}</span>
                      <span className="text-muted-foreground">{skill.level}%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full transition-all duration-1000 ease-out"
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 pt-6">
              <div className="text-center p-4 rounded-xl bg-card border border-border">
                <div className="text-3xl font-bold text-primary">8+</div>
                <div className="text-xs text-muted-foreground">Years Exp</div>
              </div>
              <div className="text-center p-4 rounded-xl bg-card border border-border">
                <div className="text-3xl font-bold text-primary">150+</div>
                <div className="text-xs text-muted-foreground">Projects</div>
              </div>
              <div className="text-center p-4 rounded-xl bg-card border border-border">
                <div className="text-3xl font-bold text-primary">80+</div>
                <div className="text-xs text-muted-foreground">Clients</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
