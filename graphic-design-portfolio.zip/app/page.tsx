import { Hero } from "@/components/hero"
import { Work } from "@/components/work"
import { About } from "@/components/about"
import { Services } from "@/components/services"
import { Contact } from "@/components/contact"
import { Navigation } from "@/components/navigation"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navigation />
      <Hero />
      <Work />
      <About />
      <Services />
      <Contact />
    </main>
  )
}
